﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;

namespace DI
{
    interface Interface1 : IWait<IWebDriver>
    {
    }
}
