﻿namespace DI
{
    public interface IDependency
    {
        string ConsWrit();
    }
}