﻿using Castle.Windsor;

namespace DI
{
    public interface ISut
    {
        string UseDependency();
    }
}