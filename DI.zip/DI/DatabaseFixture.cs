﻿using Castle.MicroKernel.Registration;
using Castle.Windsor;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;

namespace DI
{
    public class DatabaseFixture : IDisposable
    {
        public WindsorContainer Container { get; set; }
        public DatabaseFixture()
        {
            Container = new WindsorContainer();
            Container.Register(Component.For<IDependency>().ImplementedBy<Dep>());
            Container.Register(Component.For<ISut>().ImplementedBy<Sut>());
            Container.Register(Component.For<IWebDriver>().ImplementedBy<ChromeDriver>());
            var driver = Container.Resolve<IWebDriver>();
            Container.Register(Component.For<IWait<IWebDriver>>().ImplementedBy<WebDriverWait>()
                .DependsOn(Dependency.OnValue("timeout", new TimeSpan(0, 0, 5))));
            // ... initialize data in the test database ...
        }

        public void Dispose()
        {
            // ... clean up test data from the database ...
        }
    }
}
