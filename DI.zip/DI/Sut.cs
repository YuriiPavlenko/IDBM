﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DI
{
    public class Sut : ISut
    {
        private IDependency _dependency;
        public Sut(IDependency dependency)
        {
            _dependency = dependency;
        }

        public string UseDependency()
        {
           return _dependency.ConsWrit();
        }
    }
}
