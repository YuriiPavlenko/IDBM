﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace DI
{
    interface Interface2 : IWebDriver
    {
    }
}
