﻿using OpenQA.Selenium;
using System;
using SeleniumExtras.WaitHelpers;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium.Support.UI;

namespace DI
{
    public class Dep : IDependency
    {
        private readonly IWait<IWebDriver> _shit;
        private IWebDriver _driver;
        public Dep(IWebDriver driver, IWait<IWebDriver> shit)
        {
            _driver = driver;
            _shit = shit;
        }
        public string ConsWrit()
        {
            return "Demn you depend on me";
        }
    }
}
